//Author:Michael Adami
//CS 211: Project 6: Archipelago Expedition
//Island.h

#include <iostream>
#include "myList.h"
#include "queue.h"
#ifndef Island_H
#define Island_H
class Island{

    MyList IslandsList;
    Queue IslandQueue;
    int prev;
    bool containsData;
public:
    ~Island(){
        IslandsList.removeAll();
    }
    Island() {
        prev=0;
        containsData=false;
    }
    void show(){
        IslandsList.show();
    }
    void insert(int data){
        if(!EdgeExist(data)) {
            IslandsList.insert(data);
            return;
        }
        std::cout<<"Entering an edge that already exists"<<std::endl;
    }
    void removeAll(){
        IslandsList.removeAll();
    }
    void remove(int data){
        IslandsList.remove(data);
    }
    bool search(int island){
        if(IslandsList.Search(island)){
            return true;
        }
        return false;
    }
    bool EdgeExist(int island){
        if(IslandsList.Search(island))
            return true;
    }
    int getAt(int val){
        return IslandsList.getValue(val);
    }
    int getSize(){
        return IslandsList.size();
    }



};
#endif //Island_H
