//Author:Michael Adami
//CS 211: Project 6: Archipelago Expedition
//queue.h

#ifndef QUEUE_H
#define QUEUE_H
#include <iostream>
#include <cstdlib>
class Queue{
    int* arr;
    int cap;
    int front;
    int rear;
    int count;
public:
    Queue(){
        arr= new int[10];
        cap=10;
        front=0;
        rear=-1;
        count=0;
    }
    void pop(){
        if(isEmpty()){
            printf("Trying to delete inside empty queue.");
        }
        front=(front+1)%cap;
        count--;
    }
    bool isFull(){
        return (count==cap);
    }
    void push(int item){
        if(isFull()){
            printf("No space to insert\n");
            return;
        }
        rear=(rear+1)%cap;
        arr[rear]=item;
        count++;
    }
    int top(){
        if(isEmpty()){
            printf("Trying to peek into empty queue.");
            return -1;
        }
        return arr[front];
    }
    int size(){
        return count;
    }
    bool isEmpty(){
        return (size()==0);
    }
};
#endif //UNTITLED16_QUEUE_H
