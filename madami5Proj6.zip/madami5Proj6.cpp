/* Author: Michael Adami
 * CS 211: Project 6: Archipelago Expedition
 * Main.cpp
 */
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include<iostream>
#include "Island.h"
#include "queue.h"
int DebugMode=0;

class ArchipelagoExpedition {
private:
    int islands = 11;
    int numOfElem = 0;
    Island* IslandData;
    Island* temp;
    char** files;
    int fileUsing;
    int cap;
    MyList *list1;
    MyList *list2;
    Queue IslandQueue;
    void initialize(){
        for(int i=0;i<islands;i++){
            IslandData[i].insert(i);
        }
    }
public:
    ArchipelagoExpedition(){
        islands = 11;

        IslandData = new Island[islands];
        initialize();
        cap=11;
        fileUsing=0;
        files= new char*[cap];
        list1= new MyList();
        list2= new MyList();
    }

    ~ArchipelagoExpedition(){
        delete[] IslandData;
    }

    void Resize(int size) {
        temp= new Island[size];
        if(size>islands) {
            for (int i = 0; i < islands; i++) {
                temp[i]=IslandData[i];
            }
        }
        else{
            for(int i=0;i < size;i++){
                temp[i]=IslandData[i];
            }
        }
        delete[] IslandData;
        IslandData=temp;
        islands=size;
    }


 // The main loop for reading in input
 void processCommandLoop (FILE* inFile)
 {
  char  buffer[300];
  char* input;
  printf("\nEnter an input: ");
  input = fgets ( buffer, 300, inFile );   // get a line of input
  // loop until all lines are read from the input
  while (input != NULL)
  {
    // process each line of input using the strtok functions
    char* command;
    command = strtok (input , " \n\t");

    printf ("*%s*\n", command);

    if ( command == NULL )
      printf ("Blank Line\n");

    else if ( strcmp (command, "q") == 0)
      exit(1);

    else if ( strcmp (command, "?") == 0)
      showCommands();

    else if ( strcmp (command, "t") == 0)
      doShortestPath();

    else if ( strcmp (command, "r") == 0)
       doResize();

    else if ( strcmp (command, "i") == 0) {
        doInsert();
    }

    else if ( strcmp (command, "d") == 0)
      doDelete();

    else if ( strcmp (command, "l") == 0)
      doList();

    else if ( strcmp (command, "f") == 0)
      doFile();

    else if ( strcmp (command, "#") == 0)
      ;

    else
      printf ("Command is not known: %s\n", command);
    printf("\nEnter an input: ");
    input = fgets ( buffer, 300, inFile );   // get the next line of input
  }
 }

 void showCommands()
 {
   printf ("The commands for this project are:\n");
   printf ("  q (Quits the program)\n");
   printf ("  ? (Instructions)\n");
   printf ("  # (ignore this line of input. Treat the line of input as a comment)\n");
   printf ("  t <int1> <int2> (display the shortest path from island <int1> to island <int2> in one or more ferry rides.)\n");
   printf ("  r <int> (Remove all values from the archipelago expedition and resize the array to contain the number of islands as indicated.)\n");
   printf ("  i <int1> <int2> (insert the edge to indicate a ferry ride from island <int1> to island <int2>.)\n");
   printf ("  d <int1> <int2> (delete the edge that indicates a ferry ride from island <int1> to island <int2>.)\n");
   printf ("  l (List all of the items contained in the archipelago expedition.)\n");
   printf ("  f <filename> (Open the file indicated by the <filename>.) \n");
 }

 void doShortestPath ()
 {
   int val1 = 0;
   int val2 = 0;

   // get an integer value from the input
   char* next = strtok (NULL, " \n\t");
   printf("%s\n", next);
   if ( next == NULL )
   {
     printf ("Integer value expected\n");
     return;
   }
   val1 = atoi ( next );
   if ( val1 == 0 && strcmp (next, "0") != 0)
   {
     printf ("Integer value expected\n");
     return;
   }

   // get another integer value from the input
   next = strtok (NULL, " \n\t");

   printf("%s\n", next);
   if ( next == NULL )
   {
     printf ("Integer value expected\n");
     return;
   }
   val2 = atoi ( next );
   if ( val2 == 0 && strcmp (next, "0") != 0)
   {
     printf ("Integer value expected\n");
     return;
   }
   if(0<=val1<islands && 0<=val2<islands) {
       printf("Performing the Travel Command from %d to %d\n",
              val1, val2);
       breadthFirstSearch(val1, val2);
   }
   else{
       std::cout<<"Island requested out of range."<<std::endl;
   }
 }

 void doResize()
 {
   int val1 = 0;
     // get an integer value from the input
     char* next = strtok (NULL, " \n\t");
     printf("%s\n", next);
     if ( next == NULL )
     {
         printf ("Integer value expected\n");
         return;
     }
     val1 = atoi ( next );
     if ( val1 == 0 && strcmp (next, "0") != 0)
     {
         printf ("Integer value expected\n");
         return;
     }

     printf ("Performing the Resize Command with %d\n", val1 );
     if(val1>=0) {
         if (DebugMode == 1) {
             std::cout << "Resize working" << std::endl;
         }
         Resize(val1);
     }
    else {
         if (DebugMode == 1) {
             std::cout<<"Error checking working"<<std::endl;
         }
             std::cout << "Error: Resizing to a negative size." << std::endl;

     }
 }

 void doInsert() {
     int val1 = 0;
     int val2 = 0;

     // get an integer value from the input
     char *next = strtok(NULL, " \n\t");
     printf("%s\n", next);
     if (next == NULL) {
         printf("Error: Integer value expected\n");
         return;
     }
     val1 = atoi(next);
     if (val1 == 0 && strcmp(next, "0") != 0) {
         printf("Error: Integer value expected\n");
         return;
     }

     // get another integer value from the input
     next = strtok(NULL, " \n\t");

     printf("%s\n", next);
     if (next == NULL) {
         printf("Error: Integer value expected\n");
         return;
     }
     val2 = atoi(next);
     if (val2 == 0 && strcmp(next, "0") != 0) {
         printf("Error: Integer value expected\n");
         return;
     }
     if(0<=val1&&val1<islands && 0<=val2&& val2<islands) {
         if (DebugMode = 1) {
             printf("Inserting works");
         }
         IslandData[val1].insert(val2);
     }

     else
         std::cout<<"Error: Inserting an island not in range."<<std::endl;
 }
//Deletes the existing
 void doDelete()
 {
     int val1 = 0;
     int val2=0;
     // get an integer value from the input
     char *next = strtok(NULL, " \n\t");
     printf("%s\n", next);
     if (next == NULL) {
         printf("Error: Integer value expected\n");
         return;
     }
     val1 = atoi(next);
     if (val1 == 0 && strcmp(next, "0") != 0) {
         printf("Error: Integer value expected\n");
         return;
     }
     // get another integer value from the input
     next = strtok(NULL, " \n\t");

     printf("%s\n", next);
     if (next == NULL) {
         printf("Error: Integer value expected\n");
         return;
     }
     val2 = atoi(next);
     if (val2 == 0 && strcmp(next, "0") != 0) {
         printf("Error: Integer value expected\n");
         return;
     }
     if(0<=val1&&val1<islands && 0<=val2&&val2<islands) {
         if (DebugMode = 1) {
             printf("Deleting working");
         }
         if (IslandData[val1].EdgeExist(val2))
             IslandData[val1].remove(val2);
         else {
             std::cout << "Error: Deleting something non-existent." << std::endl;
             return;
         }
     }
     else {
         if (DebugMode = 1) {
             printf("Error checking works\n");
         }
         std::cout << "Error: Deleting an island not in range." << std::endl;
     }
 }
//Output entire list
 void doList()
 {
    for(int i=0;i<islands;i++){
        std::cout<<"Island "<<i<<": ";
        IslandData[i].show();
    }
 }

 void doFile()
 {
   // get a filename from the input
   char* fname = strtok (NULL, " \r\n\t");
   char input[cap];
   FILE *file;
   if (file = fopen(fname, "r")){
       std::cout<<"Error: "<< fname<<" currently in use."<<std::endl;
       return;
     }
   FILE*  pFile=fopen(fname,"r");//  2. open the file using fopen creating a new instance of FILE*
   if (pFile == NULL)
   {
     printf ("Unable to open the file\n");
     return;
   }
   printf ("Performing the File command with file: %s\n", fname);
    while(!feof(pFile)) {
        fgets(input,cap,pFile);
        processCommandLoop (pFile);
    }
    fclose(pFile);
 }
// These two functions search the graph using BreadthFirst(Finding the path from x to y)
//If none found return;
//Output true or false if found.

 MyList breadthFirstSearch(int x, int y){
    MyList visited;
    while(!IslandQueue.isEmpty()){
        IslandQueue.pop();
    }
    IslandQueue.push(x);
    if(!bfs(y,visited)){
        std::cout<<"You can NOT get from island "<< x <<" to island "<< y <<" in one or more ferry rides."<<std::endl;
        return visited;
    }
    else{
        std::cout<<"You can get from island "<< x << " to island "<<y<<" in one or more ferry rides."<<std::endl;
        return visited;
    }
 }
 bool bfs(int a,MyList visited){
    int prev;
    int cur;
     while(!IslandQueue.isEmpty()){
         if (DebugMode=1){
             printf("Pushing to Queue worked for: %d\n",cur);
         }
        cur=IslandQueue.top();
        IslandQueue.pop();

        if(cur==a){
            return true;
        }
        for(int i=0;i<IslandData[cur].getSize();i++)
            if(!visited.Search(IslandData[cur].getAt(i))){
                visited.insert(cur);
                IslandQueue.push(IslandData[cur].getAt(i));
            }
        }
    return false;
}
};

int main (int argc, char** argv)
{
  // set up the variable inFile to read from standard input
  FILE* inFile = stdin;
    DebugMode = 0;

    for (int i = 0; i < argc; i++)

        if (strcmp(argv[i], "-d") == 0)

            DebugMode = 1;

    // set up the data needed for the island adjcency list
  ArchipelagoExpedition islandData;

  // call the method that reads and parses the input
  islandData.showCommands();
  printf ("\nEnter commands at blank line\n");
  printf ("    (No prompts are given because of f command)\n");
  islandData.processCommandLoop (inFile);
  printf ("Goodbye\n");
  return 1;
 }