//Author:Michael Adami
//CS 211: Project 6: Archipelago Expedition
//Stack.h
#ifndef STACK_H
#define STACK_H
#include <iostream>
#include <cstdlib>
template <class T>
class Stack {
private:
    T *arr;
    int top;
    int cap;
public:
    Stack(){
        arr=new T[size];
        cap=10;
        top=-1;
    }
    ~Stack(){
        delete[] arr;
    }
    void push(T data){
        if(!isFull()){
            printf("No space to push.\n");
        }
        arr[++top]=data;
    }

    T pop(){
        if(isEmpty()){
            printf("Popping from empty stack");
            return NULL;
        }
        return arr[top--];
    }

    T peek(){
            if(isEmpty())
                return arr[top];
            else{
                return NULL;
            }
     }
     int size(){
        return top+1;
    }
    bool isEmpty() {
        return (top == -1);
    }
    bool isFull(){
        return top==cap-1;
    }
};
#endif //UNTITLED16_STACK_H
