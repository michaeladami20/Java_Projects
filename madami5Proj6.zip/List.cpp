//Author:Michael Adami
//CS 211: Project 6: Archipelago Expedition
//List.cpp
#include "myList.h"
#include <cstdlib>
void MyList::MyList() {
    head=NULL;
    curr=NULL;
    temp=NULL;
}
void MyList::AddNode(int addData) {
    nPtr n= new node;
    n->next= null;
    n->data=addData;
    if(head!=NULL){
        curr=head;
        while(curr->next!=NULL){
            curr=curr->next;
        }
        curr->next=n;
    }
    else{
        head=n;
    }
}
void MyList::RemoveNode(int delData) {
    nPtr delPtr =NULL;
    temp = head;
    curr = head;
    while(cur!=NULL && curr->data !=delData){
        temp=curr;
        curr= curr->next;
    }
    if(curr==NULL){
        printf("%s was not in the list",delData)
        delete delPtr;
    }
    else{
        delPtr=curr;
        curr=curr->next;
        temp->next =curr;
        delete delPtr;
    }
}
void MyList::PrintList(){
    curr=head;
    while(curr!=NULL){
        printf("%d",curr->data);

        if(curr->next!=NULL){
            printf("->")
        }
        curr=curr->next;
    }
}

